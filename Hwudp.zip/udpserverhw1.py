import socket
from math import factorial # input fuction factorial
UDP_IP = "127.0.0.1"
UDP_PORT = 5070
sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock.bind((UDP_IP, UDP_PORT))
while True:
    data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
    a = int(data)
    print "received data:","Factory of data number :", factorial(a)
